<?php

namespace App\Models;

use System\Model\Model;

class Sexo extends Model
{
    protected $table = 'sexos';
}
