<?php

namespace App\Services\Vendas;

use Dompdf\Dompdf;

class GerarCupomDeVenda
{

}
